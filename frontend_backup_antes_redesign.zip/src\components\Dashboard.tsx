import { Flame, Gauge, Medal, TrendingDown, TrendingUp } from "lucide-react";
import Card from "./Card";
import Charts from "./Charts";
import { AppData } from "../types";
import { areaLabels, calculateStreak, calculateWeeklyPoints, generateWeeklySummary, strongestArea, weakestArea, weeklyLevel } from "../utils/analytics";
import { formatHumanDate, isoToday } from "../utils/date";

const Metric = ({ label, value, icon: Icon }: { label: string; value: string | number; icon: React.ElementType }) => (
  <div className="rounded-lg border border-white/10 bg-black/20 p-4">
    <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-lg bg-blue-400/15 text-blue-200">
      <Icon size={18} />
    </div>
    <div className="text-2xl font-bold text-white">{value}</div>
    <div className="text-sm text-slate-400">{label}</div>
  </div>
);

export default function Dashboard({ data }: { data: AppData }) {
  const points = calculateWeeklyPoints(data.entries);
  const summary = generateWeeklySummary(data.entries, data.chapters);
  const strong = strongestArea(data.entries);
  const weak = weakestArea(data.entries);
  return (
    <div className="space-y-5">
      <section className="grid gap-4 md:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-lg border border-white/10 bg-gradient-to-br from-slate-900 via-slate-950 to-teal-950 p-5 shadow-glow md:p-7">
          <p className="text-sm capitalize text-teal-200">{formatHumanDate(isoToday())}</p>
          <h2 className="mt-2 max-w-2xl text-3xl font-bold text-white md:text-5xl">Tu panel de progreso personal</h2>
          <p className="mt-4 max-w-3xl text-slate-300">{summary.coachText}</p>
        </div>
        <Card title="Pulso semanal">
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg bg-green-400/10 p-3 text-green-100">
              <span>Estado</span>
              <strong>{weeklyLevel(points)}</strong>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-white/5 p-3">
              <span className="text-slate-300">Fuerte</span>
              <strong className="text-white">{areaLabels[strong]}</strong>
            </div>
            <div className="flex items-center justify-between rounded-lg bg-white/5 p-3">
              <span className="text-slate-300">A cuidar</span>
              <strong className="text-white">{areaLabels[weak]}</strong>
            </div>
          </div>
        </Card>
      </section>
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Metric label="Racha actual" value={`${calculateStreak(data.entries)} dias`} icon={Flame} />
        <Metric label="Puntos semana" value={`${points}/35`} icon={Medal} />
        <Metric label="Cumplimiento" value={`${Math.round((points / 35) * 100)}%`} icon={Gauge} />
        <Metric label="Area fuerte" value={areaLabels[strong]} icon={TrendingUp} />
        <Metric label="Area debil" value={areaLabels[weak]} icon={TrendingDown} />
      </section>
      <Charts data={data} />
    </div>
  );
}
