import { ReactNode } from "react";

export default function Card({ title, children, action }: { title?: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="rounded-lg border border-white/10 bg-white/[0.055] p-4 shadow-glow backdrop-blur md:p-5">
      {(title || action) && (
        <div className="mb-4 flex items-center justify-between gap-3">
          {title && <h2 className="text-base font-semibold text-white md:text-lg">{title}</h2>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}
