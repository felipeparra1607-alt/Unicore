import { Activity, BarChart3, Brain, Briefcase, CalendarCheck, Dumbbell, History, Target } from "lucide-react";

const tabs = [
  { id: "dashboard", label: "Dashboard", icon: Activity },
  { id: "daily", label: "Registro", icon: CalendarCheck },
  { id: "weekly", label: "Semana", icon: BarChart3 },
  { id: "goals", label: "Objetivos", icon: Target },
  { id: "history", label: "Historia", icon: History },
  { id: "ai", label: "IA", icon: Brain },
  { id: "internships", label: "Practicas", icon: Briefcase },
];

export type TabId = (typeof tabs)[number]["id"];

export default function Layout({ active, onTab, children }: { active: TabId; onTab: (tab: TabId) => void; children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 border-b border-white/10 bg-[#090b10]/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-lg bg-teal-400/15 text-teal-200">
              <Dumbbell size={21} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white">Life Tracker</h1>
              <p className="text-xs text-slate-400">Progreso diario hasta septiembre</p>
            </div>
          </div>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 pb-3">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const selected = active === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTab(tab.id)}
                className={`flex min-w-max items-center gap-2 rounded-lg px-3 py-2 text-sm transition ${
                  selected ? "bg-teal-400 text-slate-950" : "bg-white/5 text-slate-300 hover:bg-white/10"
                }`}
              >
                <Icon size={16} />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-5 md:py-8">{children}</main>
    </div>
  );
}
