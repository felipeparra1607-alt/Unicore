import React from "react";
import Dashboard from "./components/Dashboard";
import DailyEntryForm from "./components/DailyEntryForm";
import Goals from "./components/Goals";
import HistoryTracker from "./components/HistoryTracker";
import AITracker from "./components/AITracker";
import InternshipTracker from "./components/InternshipTracker";
import Layout, { TabId } from "./components/Layout";
import WeeklyReview from "./components/WeeklyReview";
import { AppData, DailyEntry } from "./types";
import { emptyEntryForDate } from "./utils/analytics";
import { isoToday } from "./utils/date";
import { clearAllData, deleteEntry, exportData, getData, importData, resetToSample, saveData, saveEntry, upsertAIItem, upsertChapter, upsertInternship } from "./utils/storage";

export default function App() {
  const [data, setData] = React.useState<AppData>(() => getData());
  const [tab, setTab] = React.useState<TabId>("dashboard");
  const [draft, setDraft] = React.useState<DailyEntry>(() => data.entries.find((entry) => entry.date === isoToday()) || emptyEntryForDate(isoToday()));
  const refresh = () => setData(getData());
  const saveDaily = (entry: DailyEntry) => {
    saveEntry(entry);
    refresh();
    setDraft(entry);
  };
  const removeDaily = (id: string) => {
    deleteEntry(id);
    refresh();
    setDraft(emptyEntryForDate(isoToday()));
  };
  const download = () => {
    const blob = new Blob([exportData()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "life-tracker-export.json";
    a.click();
    URL.revokeObjectURL(url);
  };
  const upload = (file?: File) => {
    if (!file) return;
    file.text().then((text) => {
      setData(importData(text));
      setDraft(emptyEntryForDate(isoToday()));
    });
  };
  return (
    <Layout active={tab} onTab={setTab}>
      <div className="mb-5 flex flex-wrap gap-2">
        <button className="rounded-lg bg-white/10 px-3 py-2 text-sm text-white" onClick={download}>Exportar JSON</button>
        <label className="cursor-pointer rounded-lg bg-white/10 px-3 py-2 text-sm text-white">Importar JSON<input className="hidden" type="file" accept="application/json" onChange={(e) => upload(e.target.files?.[0])} /></label>
        <button className="rounded-lg bg-blue-400/15 px-3 py-2 text-sm text-blue-100" onClick={() => setData(resetToSample())}>Cargar ejemplos</button>
        <button className="rounded-lg bg-red-400/15 px-3 py-2 text-sm text-red-100" onClick={() => confirm("Resetear todos los datos?") && setData(clearAllData())}>Resetear datos</button>
      </div>
      {tab === "dashboard" && <Dashboard data={data} />}
      {tab === "daily" && <DailyEntryForm entries={data.entries} draft={draft} setDraft={setDraft} onSave={saveDaily} onDelete={removeDaily} />}
      {tab === "weekly" && <WeeklyReview data={data} />}
      {tab === "goals" && <Goals goals={data.goals} onSave={(goals) => { const next = { ...data, goals }; saveData(next); setData(next); }} />}
      {tab === "history" && <HistoryTracker chapters={data.chapters} onSave={(chapter) => { upsertChapter(chapter); refresh(); }} />}
      {tab === "ai" && <AITracker items={data.aiItems} onSave={(item) => { upsertAIItem(item); refresh(); }} />}
      {tab === "internships" && <InternshipTracker items={data.internships} onSave={(item) => { upsertInternship(item); refresh(); }} />}
    </Layout>
  );
}
