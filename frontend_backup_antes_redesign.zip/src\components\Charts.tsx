import { Area, AreaChart, Bar, BarChart, CartesianGrid, Line, LineChart, PolarAngleAxis, Radar, RadarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import Card from "./Card";
import { AppData } from "../types";
import { areaCompletion, areaLabels, chartWeekRows, minutesByArea, recentWeightRows, weeklyEvolution } from "../utils/analytics";

export default function Charts({ data }: { data: AppData }) {
  const completion = areaCompletion(data.entries);
  const completionRows = Object.entries(completion).map(([key, value]) => ({ area: areaLabels[key as keyof typeof areaLabels], value }));
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card title="Puntos diarios">
        <div className="h-64">
          <ResponsiveContainer>
            <BarChart data={chartWeekRows(data.entries)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid #334155" }} />
              <Bar dataKey="points" fill="#2dd4bf" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Energia diaria">
        <div className="h-64">
          <ResponsiveContainer>
            <LineChart data={chartWeekRows(data.entries)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis domain={[0, 5]} stroke="#94a3b8" />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid #334155" }} />
              <Line type="monotone" dataKey="energy" stroke="#60a5fa" strokeWidth={3} dot={{ fill: "#60a5fa" }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Minutos por area">
        <div className="h-64">
          <ResponsiveContainer>
            <BarChart data={minutesByArea(data.entries)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid #334155" }} />
              <Bar dataKey="minutes" fill="#22c55e" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Peso corporal">
        <div className="h-64">
          <ResponsiveContainer>
            <AreaChart data={recentWeightRows(data.entries)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid #334155" }} />
              <Area dataKey="weight" stroke="#a78bfa" fill="#a78bfa33" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Cumplimiento por area">
        <div className="h-64">
          <ResponsiveContainer>
            <RadarChart data={completionRows}>
              <PolarAngleAxis dataKey="area" stroke="#cbd5e1" />
              <Radar dataKey="value" stroke="#facc15" fill="#facc15" fillOpacity={0.24} />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid #334155" }} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card title="Evolucion semanal">
        <div className="h-64">
          <ResponsiveContainer>
            <LineChart data={weeklyEvolution(data.entries)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="week" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid #334155" }} />
              <Line type="monotone" dataKey="points" stroke="#fb7185" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
