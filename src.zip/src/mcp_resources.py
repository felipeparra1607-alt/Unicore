import json

from src.academic_risk_tools import (
    build_subject_risk,
)
from src.analytics_tools import (
    build_learning_analytics,
)
from src.unicore_dashboard import (
    build_dashboard_data,
)


def _json(data) -> str:
    """
    Convierte la respuesta del Resource
    a JSON legible y compatible con español.
    """

    return json.dumps(
        data,
        ensure_ascii=False,
        indent=2,
        default=str,
    )


def _error(message: str) -> str:
    return _json({
        "ok": False,
        "error": message,
    })


def _build_profile() -> dict:
    """
    Perfil global extremadamente compacto.

    Objetivo:
    dar al modelo una primera vista de UniCore
    gastando muy pocos tokens.
    """

    data = build_dashboard_data()

    if not data.get("ok"):
        return data

    hero = data.get(
        "hero",
        {},
    )

    metrics = data.get(
        "metrics",
        {},
    )

    return {
        "ok": True,
        "level": hero.get(
            "level"
        ),
        "total_xp": hero.get(
            "total_xp"
        ),
        "current_streak": hero.get(
            "current_streak"
        ),
        "longest_streak": hero.get(
            "longest_streak"
        ),
        "study_minutes_today": metrics.get(
            "study_minutes_today"
        ),
        "study_minutes_last_7_days": (
            metrics.get(
                "study_minutes_last_7_days"
            )
        ),
        "quiz_average_percentage": (
            metrics.get(
                "quiz_average_percentage"
            )
        ),
        "pending_task_count": metrics.get(
            "pending_task_count"
        ),
        "overdue_task_count": metrics.get(
            "overdue_task_count"
        ),
        "due_review_count": metrics.get(
            "due_review_count"
        ),
    }


def _build_today() -> dict:
    """
    Información necesaria para responder:
    ¿qué necesita mi atención hoy?
    """

    data = build_dashboard_data()

    if not data.get("ok"):
        return data

    metrics = data.get(
        "metrics",
        {},
    )

    missions = data.get(
        "missions",
        {},
    )

    return {
        "ok": True,
        "study_minutes_today": metrics.get(
            "study_minutes_today"
        ),
        "pending_task_count": metrics.get(
            "pending_task_count"
        ),
        "overdue_task_count": metrics.get(
            "overdue_task_count"
        ),
        "due_review_count": metrics.get(
            "due_review_count"
        ),
        "next_assessment": data.get(
            "next_assessment"
        ),
        "next_boss": data.get(
            "next_boss"
        ),
        "priorities": data.get(
            "priorities",
            [],
        )[:5],
        "missions": missions.get(
            "items",
            [],
        ),
    }


def _build_subjects() -> dict:
    """
    Lista compacta de asignaturas.

    No devuelve documentos, historial completo
    ni toda la actividad académica.
    """

    data = build_dashboard_data()

    if not data.get("ok"):
        return data

    subjects = data.get(
        "subjects",
        [],
    )

    compact = []

    for subject in subjects:
        grade = subject.get(
            "grade",
            {},
        )

        compact.append({
            "id": subject.get(
                "id"
            ),
            "name": subject.get(
                "name"
            ),
            "xp": subject.get(
                "xp"
            ),
            "study_minutes": subject.get(
                "study_minutes"
            ),
            "quiz_average_percentage": (
                subject.get(
                    "quiz_average_percentage"
                )
            ),
            "current_grade": grade.get(
                "current_grade_out_of_10"
            ),
            "next_assessment": subject.get(
                "next_assessment"
            ),
        })

    return {
        "ok": True,
        "count": len(compact),
        "subjects": compact,
    }


def _build_subject(
    subject_id: int,
) -> dict:
    """
    Snapshot compacto de una asignatura.
    """

    data = build_dashboard_data(
        subject_id=subject_id
    )

    if not data.get("ok"):
        return data

    hero = data.get(
        "hero",
        {},
    )

    metrics = data.get(
        "metrics",
        {},
    )

    risk = data.get(
        "academic_risk"
    )

    if risk is None:
        risk_result = (
            build_subject_risk(
                subject_id
            )
        )

        if risk_result.get("ok"):
            risk = risk_result

    risk_summary = None

    if isinstance(
        risk,
        dict,
    ):
        risk_data = risk.get(
            "risk",
            {},
        )

        risk_summary = {
            "score": risk_data.get(
                "score"
            ),
            "level": risk_data.get(
                "level"
            ),
        }

    return {
        "ok": True,
        "subject": data.get(
            "subject"
        ),
        "level": hero.get(
            "level"
        ),
        "xp": hero.get(
            "total_xp"
        ),
        "current_streak": hero.get(
            "current_streak"
        ),
        "study_minutes_last_7_days": (
            metrics.get(
                "study_minutes_last_7_days"
            )
        ),
        "quiz_average_percentage": (
            metrics.get(
                "quiz_average_percentage"
            )
        ),
        "pending_task_count": metrics.get(
            "pending_task_count"
        ),
        "due_review_count": metrics.get(
            "due_review_count"
        ),
        "next_assessment": data.get(
            "next_assessment"
        ),
        "grade": data.get(
            "grade"
        ),
        "risk": risk_summary,
    }


def _build_subject_dashboard(
    subject_id: int,
) -> dict:
    """
    Versión intermedia del dashboard.

    Más detallada que unicore://subjects/{id},
    pero mucho más pequeña que enviar todo
    el estado de UniCore.
    """

    data = build_dashboard_data(
        subject_id=subject_id
    )

    if not data.get("ok"):
        return data

    return {
        "ok": True,
        "subject": data.get(
            "subject"
        ),
        "hero": data.get(
            "hero"
        ),
        "metrics": data.get(
            "metrics"
        ),
        "next_assessment": data.get(
            "next_assessment"
        ),
        "next_boss": data.get(
            "next_boss"
        ),
        "grade": data.get(
            "grade"
        ),
        "priorities": data.get(
            "priorities",
            [],
        )[:5],
        "missions": data.get(
            "missions"
        ),
    }


def _build_subject_analytics(
    subject_id: int,
) -> dict:
    """
    Analytics únicamente de la asignatura.
    """

    return build_learning_analytics(
        subject_id=subject_id,
        comparison_days=14,
    )


def _build_subject_risk(
    subject_id: int,
) -> dict:
    """
    Riesgo académico únicamente.
    """

    return build_subject_risk(
        subject_id
    )


def _build_subject_grade(
    subject_id: int,
) -> dict:
    """
    Devuelve únicamente el estado de notas.
    """

    data = build_dashboard_data(
        subject_id=subject_id
    )

    if not data.get("ok"):
        return data

    return {
        "ok": True,
        "subject": data.get(
            "subject"
        ),
        "grade": data.get(
            "grade"
        ),
        "next_assessment": data.get(
            "next_assessment"
        ),
    }


def _build_missions() -> dict:
    """
    Misiones actuales sin cargar
    el resto del dashboard.
    """

    data = build_dashboard_data()

    if not data.get("ok"):
        return data

    return {
        "ok": True,
        "missions": data.get(
            "missions"
        ),
    }


def _build_next_boss() -> dict:
    """
    Próximo Boss Battle.

    De momento no exponemos todos los Bosses
    para mantener este Resource pequeño.
    """

    data = build_dashboard_data()

    if not data.get("ok"):
        return data

    return {
        "ok": True,
        "next_boss": data.get(
            "next_boss"
        ),
    }


def register_mcp_resources(
    mcp,
) -> None:
    """
    Registra el catálogo inicial
    de Resources MCP de UniCore.
    """

    @mcp.resource(
        "unicore://profile"
    )
    def profile_resource() -> str:
        """
        Perfil académico global compacto.
        """

        return _json(
            _build_profile()
        )

    @mcp.resource(
        "unicore://today"
    )
    def today_resource() -> str:
        """
        Información relevante para hoy.
        """

        return _json(
            _build_today()
        )

    @mcp.resource(
        "unicore://subjects"
    )
    def subjects_resource() -> str:
        """
        Lista compacta de asignaturas.
        """

        return _json(
            _build_subjects()
        )

    @mcp.resource(
        "unicore://subjects/{subject_id}"
    )
    def subject_resource(
        subject_id: int,
    ) -> str:
        """
        Snapshot compacto de una asignatura.
        """

        return _json(
            _build_subject(
                subject_id
            )
        )

    @mcp.resource(
        (
            "unicore://subjects/"
            "{subject_id}/dashboard"
        )
    )
    def subject_dashboard_resource(
        subject_id: int,
    ) -> str:
        """
        Estado académico ampliado
        de una asignatura.
        """

        return _json(
            _build_subject_dashboard(
                subject_id
            )
        )

    @mcp.resource(
        (
            "unicore://subjects/"
            "{subject_id}/analytics"
        )
    )
    def subject_analytics_resource(
        subject_id: int,
    ) -> str:
        """
        Tendencias y eficiencia de estudio.
        """

        return _json(
            _build_subject_analytics(
                subject_id
            )
        )

    @mcp.resource(
        (
            "unicore://subjects/"
            "{subject_id}/risk"
        )
    )
    def subject_risk_resource(
        subject_id: int,
    ) -> str:
        """
        Señales de riesgo académico.
        """

        return _json(
            _build_subject_risk(
                subject_id
            )
        )

    @mcp.resource(
        (
            "unicore://subjects/"
            "{subject_id}/grade"
        )
    )
    def subject_grade_resource(
        subject_id: int,
    ) -> str:
        """
        Estado actual de notas.
        """

        return _json(
            _build_subject_grade(
                subject_id
            )
        )

    @mcp.resource(
        "unicore://missions"
    )
    def missions_resource() -> str:
        """
        Misiones actuales.
        """

        return _json(
            _build_missions()
        )

    @mcp.resource(
        "unicore://boss"
    )
    def boss_resource() -> str:
        """
        Próximo Boss Battle.
        """

        return _json(
            _build_next_boss()
        )